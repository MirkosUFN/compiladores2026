if (x > 0) {
    if (y > 0) {
        z = 0;
    }
}