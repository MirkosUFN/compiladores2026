import json
import os

# Listas/coleções para guardar os elementos do AFD
estados = []
estados_finais = []
simbolos = []
regras_transicao = []

# Abrindo o arquivo de config do AFD
with open("config.md", "r", encoding="utf-8") as f:
    # Separa as linhas do arquivo e remove as linhas vazias
    linhas = [linha.strip() for linha in f if linha.strip() != ""]

# Linha 0: todos os estados (o primeiro é o estado inicial, por convenção)
linha_estados = linhas[0].split()
estados.extend(linha_estados)
estado_inicial = linha_estados[0]

# Linha 1: todos os símbolos do alfabeto
linha_simbolos = linhas[1].split()
simbolos.extend(linha_simbolos)

# Linha 2: todos os estados finais (formato Qx:NOME)
linha_estados_finais = linhas[2].split()
estados_finais.extend([e.split(":")[0] for e in linha_estados_finais])

# Mapa estado final -> tipo (ex: Q1 -> INTEIRO)
tipo_por_estado_final = {}
for par in linha_estados_finais:
    estado, tipo = par.split(":")
    tipo_por_estado_final[estado] = tipo

# Linhas 3 em diante: regras de transicao (formato Qorigem:simbolo:Qdestino)
linhas_regras = linhas[3:]
for linha in linhas_regras:
    regras = linha.split()
    regras_transicao.extend(regras)

# Mapa de transições: { "Qorigem": { "simbolo": "Qdestino" } }
transicoes = {}
for regra in regras_transicao:
    origem, simbolo, destino = regra.split(":")
    if origem not in transicoes:
        transicoes[origem] = {}
    transicoes[origem][simbolo] = destino


def tipo_do_termo(termo):
    """
    Percorre o AFD com o termo inteiro e retorna o tipo do estado final
    alcançado (ex: "INTEIRO", "FRACIONÁRIO", "NOMEVARIAVEL") ou None se o
    termo não for reconhecido.
    """
    estado_atual = estado_inicial

    for simbolo in termo:
        proximo_estado = transicoes.get(estado_atual, {}).get(simbolo)
        if not proximo_estado:
            return None
        estado_atual = proximo_estado

    return (
        tipo_por_estado_final[estado_atual]
        if estado_atual in estados_finais
        else None
    )


# Lê o arquivo de entrada (um termo por linha) e monta a tabela de símbolos
with open("numeros.txt", "r", encoding="utf-8") as f:
    codigo_fonte = f.read().splitlines()

tamanho_bytes = os.path.getsize("numeros.txt")
print(
    f"{tamanho_bytes} bytes \nProcessando {len(codigo_fonte)} linhas do arquivo numeros.txt..."
)

tab_simbolos = []
proximo_id = 1

for indice, linha in enumerate(codigo_fonte):
    numero_da_linha = indice + 1

    for termo in linha.strip().split(" "):
        if termo == "":
            continue

        tipo = tipo_do_termo(termo)
        if not tipo:
            continue

        tab_simbolos.append(
            {
                "id": proximo_id,
                "token": termo,
                "tipo": tipo,
                "linha": numero_da_linha,
            }
        )
        proximo_id += 1

with open("tabSimbolos.json", "w", encoding="utf-8") as f:
    json.dump(tab_simbolos, f, indent=2, ensure_ascii=False)

print(
    f"Tabela de simbolos gerada em tabSimbolos.json ({len(tab_simbolos)} tokens reconhecidos)."
)
