# Configuração do Analisador Léxico

Este projeto é um analisador léxico em Python projetado para reconhecer e categorizar tokens de operadores relacionais e de atribuição.

## Tokens Mapeados

- `==` : `EQ` (Igual)
- `!=` : `NE` (Diferente)
- `<=` : `LE` (Menor ou igual)
- `>=` : `GE` (Maior ou igual)
- `=`  : `ASSIGN` (Atribuição)
- `<`  : `LT` (Menor que)
- `>`  : `GT` (Maior que)

## Execução

Execute o script `main.py` para analisar o código de exemplo e gerar o arquivo `tabSimbolos.json`.
