import json
import re

# Definicao dos padroes de tokens para os operadores relacionais e de atribuicao
TOKEN_TYPES = [
    ('EQ', r'=='),        # Igualdade
    ('NE', r'!='),        # Diferente
    ('LE', r'<='),        # Menor ou igual
    ('GE', r'>='),        # Maior ou igual
    ('ASSIGN', r'='),     # Atribuicao
    ('LT', r'<'),         # Menor que
    ('GT', r'>'),         # Maior que
    ('NUMBER', r'\d+'),   # Numeros
    ('IDENT', r'[a-zA-Z_][a-zA-Z0-9_]*'), # Identificadores
    ('SKIP', r'[ \t\n]+'), # Espacos e quebras de linha
]

def analisar_codigo(codigo_fonte):
    regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in TOKEN_TYPES)
    tokens_encontrados = []
    
    for mo in re.finditer(regex, codigo_fonte):
        tipo = mo.lastgroup
        valor = mo.group()
        
        if tipo == 'SKIP':
            continue
        
        tokens_encontrados.append({
            "token": tipo,
            "lexema": valor
        })
        
    return tokens_encontrados

def salvar_tabela_simbolos(tokens, caminho_arquivo="tabSimbolos.json"):
    with open(caminho_arquivo, "w", encoding="utf-8") as f:
        json.dump(tokens, f, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    # Exemplo de codigo com todos os operadores relacionais e de atribuicao
    codigo = """
    a = 10
    b == 20
    x <= 5
    y >= 3
    z != 0
    """
    
    tokens = analisar_codigo(codigo)
    salvar_tabela_simbolos(tokens)
    print("Tokens processados e salvos em tabSimbolos.json com sucesso.")
