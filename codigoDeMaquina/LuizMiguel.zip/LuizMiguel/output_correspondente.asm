; Gerado por c3e2asm (C3E -> x86-64, NASM, sintaxe Intel)
; Montar: nasm -f elf64 arq.asm -o arq.o && ld arq.o -o arq

section .data
    a          dq 0
    b          dq 0
    c          dq 0
    d          dq 0
    t1         dq 0
    t2         dq 0
    t3         dq 0
    t4         dq 0
    t5         dq 0
    x          dq 0
    t6         dq 0
    t7         dq 0
    t8         dq 0
    t9         dq 0
    z          dq 0
    t10        dq 0
    t11        dq 0
    t12        dq 0
    t13        dq 0
    t14        dq 0
    y          dq 0
    q          dq 0
    r          dq 0

section .text
    global _start

_start:
    ; [3] a = 7
    mov  rax, 7
    mov  [a], rax

    ; [4] b = 5
    mov  rax, 5
    mov  [b], rax

    ; [5] c = 2
    mov  rax, 2
    mov  [c], rax

    ; [6] d = 3
    mov  rax, 3
    mov  [d], rax

    ; [9] t1 = b - c
    mov  rax, qword [b]
    sub  rax, qword [c]
    mov  [t1], rax

    ; [10] t2 = a * t1
    mov  rax, qword [a]
    imul rax, qword [t1]
    mov  [t2], rax

    ; [11] t3 = a + t2
    mov  rax, qword [a]
    add  rax, qword [t2]
    mov  [t3], rax

    ; [12] t4 = t1 * d
    mov  rax, qword [t1]
    imul rax, qword [d]
    mov  [t4], rax

    ; [13] t5 = t3 + t4
    mov  rax, qword [t3]
    add  rax, qword [t4]
    mov  [t5], rax

    ; [14] x = t5
    mov  rax, qword [t5]
    mov  [x], rax

    ; [17] t6 = a + b
    mov  rax, qword [a]
    add  rax, qword [b]
    mov  [t6], rax

    ; [18] t7 = t6 * t6
    mov  rax, qword [t6]
    imul rax, qword [t6]
    mov  [t7], rax

    ; [19] t8 = c / d
    mov  rax, qword [c]
    cqo                     ; estende o sinal de RAX para RDX
    idiv qword [d]
    mov  [t8], rax

    ; [20] t9 = t7 - t8
    mov  rax, qword [t7]
    sub  rax, qword [t8]
    mov  [t9], rax

    ; [21] z = t9
    mov  rax, qword [t9]
    mov  [z], rax

    ; [24] t10 = minus c
    mov  rax, qword [c]
    neg  rax
    mov  [t10], rax

    ; [25] t11 = b * t10
    mov  rax, qword [b]
    imul rax, qword [t10]
    mov  [t11], rax

    ; [26] t12 = minus c
    mov  rax, qword [c]
    neg  rax
    mov  [t12], rax

    ; [27] t13 = b * t12
    mov  rax, qword [b]
    imul rax, qword [t12]
    mov  [t13], rax

    ; [28] t14 = t11 + t13
    mov  rax, qword [t11]
    add  rax, qword [t13]
    mov  [t14], rax

    ; [29] y = t14
    mov  rax, qword [t14]
    mov  [y], rax

    ; [32] q = y / 6
    mov  rax, qword [y]
    cqo                     ; estende o sinal de RAX para RDX
    mov  rcx, 6
    idiv rcx
    mov  [q], rax

    ; [33] r = x + z
    mov  rax, qword [x]
    add  rax, qword [z]
    mov  [r], rax

    ; [34] r = r + q
    mov  rax, qword [r]
    add  rax, qword [q]
    mov  [r], rax

    ; fim: sys_exit com o valor da última variável atribuída
    mov  rdi, [r]
    mov  rax, 60
    syscall
