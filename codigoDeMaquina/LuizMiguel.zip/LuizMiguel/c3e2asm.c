/*
 * Conversor de C3E (código de três endereços) para Assembly x86-64.
 * Aluno: Luiz Miguel - Compiladores - UFN - Prof. Mirkos O. Martins
 *
 * C3E aceito (uma instrução por linha):
 *     x = y op z      op em  +  -  *  /     (y e z: variável ou inteiro)
 *     x = y           cópia / atribuição de constante
 *     x = minus y     menos unário (forma do livro do dragão)
 * Linhas em branco e comentários (# ou //) são ignorados; ';' final é opcional.
 *
 * Saída: programa NASM, sintaxe Intel, x86-64 Linux.
 *   - cada variável/temporário vira um qword (64 bits, com sinal) em .data
 *   - cada instrução C3E vira um bloco comentado com a linha original
 *   - o programa termina com o valor da última variável atribuída como
 *     código de saída (conferir com `echo $?`, módulo 256)
 *
 * Compilar:  gcc -Wall -O2 -o c3e2asm c3e2asm.c
 * Usar:      ./c3e2asm entrada.c3e [saida.asm]
 * Montar:    nasm -f elf64 saida.asm -o saida.o && ld saida.o -o saida
 */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NOME  64
#define MAX_LINHA 512
#define MAX_VARS  4096

typedef enum { COPIA, MINUS, BINARIA } Tipo;

typedef struct {
    Tipo tipo;
    int  linha;                   /* número da linha no arquivo de entrada */
    char texto[MAX_LINHA];        /* instrução original (para o comentário) */
    char x[MAX_NOME], y[MAX_NOME], z[MAX_NOME];
    char op;
} Instrucao;

static Instrucao *prog = NULL;
static int n_inst = 0, cap_inst = 0;

static char vars[MAX_VARS][MAX_NOME];
static int n_vars = 0;

static void erro(int linha, const char *msg, const char *detalhe) {
    fprintf(stderr, "erro: linha %d: %s: '%s'\n", linha, msg, detalhe);
    exit(2);
}

static int eh_numero(const char *s) {
    if (*s == '-') s++;
    if (!*s) return 0;
    for (; *s; s++)
        if (!isdigit((unsigned char)*s)) return 0;
    return 1;
}

static int eh_reservado(const char *s) {
    static const char *r[] = {"rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rsp", "rbp",
                              "eax", "ebx", "ecx", "edx", "ax", "bx", "cx", "dx",
                              "al", "bl", "cl", "dl", "minus", NULL};
    for (int i = 0; r[i]; i++)
        if (strcmp(s, r[i]) == 0) return 1;
    return 0;
}

static void usa_var(const char *s) {
    if (eh_numero(s)) return;
    for (int i = 0; i < n_vars; i++)
        if (strcmp(vars[i], s) == 0) return;
    if (n_vars == MAX_VARS) { fprintf(stderr, "erro: variáveis demais\n"); exit(2); }
    strcpy(vars[n_vars++], s);
}

/* ---------- analisador léxico simples sobre uma linha ---------- */

static const char *p;   /* posição atual na linha */

static void pula_espacos(void) { while (isspace((unsigned char)*p)) p++; }

/* lê um identificador; retorna 1 se conseguiu */
static int le_ident(char *dst) {
    pula_espacos();
    if (!(isalpha((unsigned char)*p) || *p == '_')) return 0;
    int n = 0;
    while (isalnum((unsigned char)*p) || *p == '_') {
        if (n == MAX_NOME - 1) return 0;
        dst[n++] = *p++;
    }
    dst[n] = '\0';
    return 1;
}

/* lê um operando: identificador ou inteiro (com '-' opcional) */
static int le_operando(char *dst) {
    pula_espacos();
    if (*p == '-' || isdigit((unsigned char)*p)) {
        int n = 0;
        if (*p == '-') dst[n++] = *p++;
        if (!isdigit((unsigned char)*p)) return 0;
        while (isdigit((unsigned char)*p)) {
            if (n == MAX_NOME - 1) return 0;
            dst[n++] = *p++;
        }
        dst[n] = '\0';
        return !isalpha((unsigned char)*p) && *p != '_';
    }
    return le_ident(dst);
}

/* tira comentário, espaços e ';' final; devolve 0 se a linha ficou vazia */
static int limpa(char *s) {
    char *c1 = strstr(s, "//"), *c2 = strchr(s, '#');
    if (c1) *c1 = '\0';
    if (c2) *c2 = '\0';
    size_t n = strlen(s);
    while (n && (isspace((unsigned char)s[n - 1]) || s[n - 1] == ';')) s[--n] = '\0';
    char *ini = s;
    while (isspace((unsigned char)*ini)) ini++;
    memmove(s, ini, strlen(ini) + 1);
    return s[0] != '\0';
}

static void analisa_linha(char *s, int linha) {
    Instrucao in;
    memset(&in, 0, sizeof in);
    in.linha = linha;
    snprintf(in.texto, sizeof in.texto, "%s", s);
    p = s;

    if (!le_ident(in.x)) erro(linha, "instrução C3E inválida", s);
    pula_espacos();
    if (*p++ != '=') erro(linha, "instrução C3E inválida", s);

    /* x = minus y ? */
    const char *salva = p;
    char tmp[MAX_NOME];
    if (le_ident(tmp) && strcmp(tmp, "minus") == 0) {
        in.tipo = MINUS;
        if (!le_operando(in.y)) erro(linha, "instrução C3E inválida", s);
    } else {
        p = salva;
        if (!le_operando(in.y)) erro(linha, "instrução C3E inválida", s);
        pula_espacos();
        if (*p == '\0') {
            in.tipo = COPIA;
        } else if (strchr("+-*/", *p)) {
            in.tipo = BINARIA;
            in.op = *p++;
            if (!le_operando(in.z)) erro(linha, "instrução C3E inválida", s);
        } else {
            erro(linha, "instrução C3E inválida", s);
        }
    }
    pula_espacos();
    if (*p != '\0') erro(linha, "instrução C3E inválida (mais de um operador?)", s);

    if (eh_reservado(in.x) || eh_reservado(in.y) || (in.tipo == BINARIA && eh_reservado(in.z)))
        erro(linha, "nome reservado", s);
    if (in.tipo == BINARIA && in.op == '/' && eh_numero(in.z) && atoll(in.z) == 0)
        erro(linha, "divisão por zero constante", s);

    /* ordem de declaração: operandos antes do destino */
    usa_var(in.y);
    if (in.tipo == BINARIA) usa_var(in.z);
    usa_var(in.x);

    if (n_inst == cap_inst) {
        cap_inst = cap_inst ? 2 * cap_inst : 64;
        prog = realloc(prog, cap_inst * sizeof *prog);
        if (!prog) { perror("realloc"); exit(1); }
    }
    prog[n_inst++] = in;
}

/* ---------- geração de código ---------- */

/* operando NASM: imediato ou memória */
static const char *operando(const char *s, char *buf) {
    if (eh_numero(s)) snprintf(buf, MAX_NOME + 16, "%s", s);
    else snprintf(buf, MAX_NOME + 16, "qword [%s]", s);
    return buf;
}

static void gera(FILE *out) {
    char b1[MAX_NOME + 16], b2[MAX_NOME + 16];

    fprintf(out, "; Gerado por c3e2asm (C3E -> x86-64, NASM, sintaxe Intel)\n");
    fprintf(out, "; Montar: nasm -f elf64 arq.asm -o arq.o && ld arq.o -o arq\n\n");
    fprintf(out, "section .data\n");
    for (int i = 0; i < n_vars; i++) fprintf(out, "    %-10s dq 0\n", vars[i]);
    fprintf(out, "\nsection .text\n    global _start\n\n_start:\n");

    for (int i = 0; i < n_inst; i++) {
        Instrucao *in = &prog[i];
        fprintf(out, "    ; [%d] %s\n", in->linha, in->texto);
        fprintf(out, "    mov  rax, %s\n", operando(in->y, b1));
        switch (in->tipo) {
        case COPIA:
            break;
        case MINUS:
            fprintf(out, "    neg  rax\n");
            break;
        case BINARIA:
            switch (in->op) {
            case '+': fprintf(out, "    add  rax, %s\n", operando(in->z, b2)); break;
            case '-': fprintf(out, "    sub  rax, %s\n", operando(in->z, b2)); break;
            case '*': fprintf(out, "    imul rax, %s\n", operando(in->z, b2)); break;
            case '/':  /* RDX:RAX / divisor -> quociente em RAX */
                fprintf(out, "    cqo                     ; estende o sinal de RAX para RDX\n");
                if (eh_numero(in->z)) {   /* idiv não aceita imediato */
                    fprintf(out, "    mov  rcx, %s\n", in->z);
                    fprintf(out, "    idiv rcx\n");
                } else {
                    fprintf(out, "    idiv qword [%s]\n", in->z);
                }
                break;
            }
            break;
        }
        fprintf(out, "    mov  [%s], rax\n\n", in->x);
    }

    fprintf(out, "    ; fim: sys_exit com o valor da última variável atribuída\n");
    if (n_inst) fprintf(out, "    mov  rdi, [%s]\n", prog[n_inst - 1].x);
    else        fprintf(out, "    xor  edi, edi\n");
    fprintf(out, "    mov  rax, 60\n    syscall\n");
}

int main(int argc, char **argv) {
    if (argc < 2 || argc > 3) {
        fprintf(stderr, "uso: %s entrada.c3e [saida.asm]\n", argv[0]);
        return 1;
    }
    FILE *in = fopen(argv[1], "r");
    if (!in) { perror(argv[1]); return 1; }

    char linha[MAX_LINHA];
    int n = 0;
    while (fgets(linha, sizeof linha, in)) {
        n++;
        if (limpa(linha)) analisa_linha(linha, n);
    }
    fclose(in);

    FILE *out = stdout;
    if (argc == 3 && !(out = fopen(argv[2], "w"))) { perror(argv[2]); return 1; }
    gera(out);
    if (out != stdout) fclose(out);
    free(prog);
    return 0;
}
